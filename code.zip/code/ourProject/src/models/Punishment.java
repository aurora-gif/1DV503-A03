
package models;

import java.util.Date;


public class Punishment {

    private int punishment_id;
    private String type;
    private Date date;
    private String source;
    private String description;
    private Employee employee;

    public Punishment(int punishment_id, String type, Date date, String source, String description, Employee emp) {
        this.punishment_id = punishment_id;
        this.type = type;
        this.date = date;
        this.source = source;
        this.description = description;
        this.employee = emp;
    }

    public Punishment(String type, Date date, String source, String description, Employee emp) {
        this.type = type;
        this.date = date;
        this.source = source;
        this.description = description;
        this.employee = emp;
    }

    public int getPunishment_id() {
        return punishment_id;
    }

    public void setPunishment_id(int punishment_id) {
        this.punishment_id = punishment_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }


    public Object[] to_row() {
        Object[] row = new Object[]{punishment_id, type, source, description, date};
        return row;

    }

}
