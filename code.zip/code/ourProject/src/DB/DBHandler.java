
package DB;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Certificate;
import models.Department;
import models.Employee;
import models.Job;
import models.Punishment;
import models.Reward;


public class DBHandler {

    private static DBConnection connection;

    public static void connect(String username, String password) throws SQLException {
        connection = DBConnection.connect("hrdb", username, password);
    }

    public static int save_employee(Employee employee) {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String birth_date = format.format(employee.getBirth_date());
        String hire_date = format.format(employee.getHire_date());

        String sql = "insert into hrdb.employees (first_name,last_name,father_name,mother_name,birth_date,hire_date,"
                + " salary,blood_type,gender,departments_dep_id, jobs_job_id) values ('"
                + employee.getFirst_name() + "','" + employee.getLast_name() + "','" + employee.getFather_name() + "','"
                + employee.getMother_name() + "','" + birth_date + "','" + hire_date + "',"
                + employee.getSalary() + ",'" + employee.getBlood_type() + "','" + employee.getGender() + "'," + employee.getDepartment().getDep_id() + "," + employee.getJob().getJob_id() + ")";
        System.out.println(sql);
        int error = connection.execute_update(sql);
        return error;
    }

    public static List<Employee> getAllPeople() {
        List<Employee> people = new ArrayList<>();
        String query = "select * from hrdb.employees";
        ResultSet result = connection.execute_query(query);

        try {
            while (result.next()) {
                int employee_id = result.getInt(1);

                String first_name = result.getString(2);
                String last_name = result.getString(3);
                String father_name = result.getString(4);
                String mother_name = result.getString(5);
                Date birthdate = result.getDate(6);
                Date hiredate = result.getDate(7);
                int salary = result.getInt(8);
                String blood_type = result.getString(9);
                String gender = result.getString(10);
                int dep_id = result.getInt(11);
                int job_id = result.getInt(12);
                Department department = getDepartmentByID(dep_id);
                Job job = getJobByID(job_id);

                Employee employee = new Employee(employee_id, first_name, last_name, father_name, mother_name, birthdate, hiredate, blood_type, gender, salary, job, department);
                people.add(employee);
            }

            /*for (Employee p : people) {
                p.setCertificates(getCertificatesForEmployee(p));
                ///////////// same for rewards
                //////////// same for punishments
            }*/
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return people;
    }

    public static Department getDepartmentByID(int id) {
        Department department = null;
        String query = "select * from hrdb.departments where dep_id = " + id;
        ResultSet result = connection.execute_query(query);
        try {

            result.next();
            int dep_id = result.getInt(1);
            String name = result.getString(2);
            department = new Department(dep_id, name);

        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return department;

    }

    public static List<Department> getAllDepartments() {

        List<Department> departments = new ArrayList<>();
        String query = "select * from hrdb.departments";
        ResultSet result = connection.execute_query(query);
        try {

            while (result.next()) {
                int dep_id = result.getInt(1);
                String name = result.getString(2);
                Department department = new Department(dep_id, name);
                departments.add(department);
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return departments;

    }

    public static Job getJobByID(int id) {
        Job job = null;
        String query = "select * from hrdb.jobs where job_id = " + id;
        ResultSet result = connection.execute_query(query);
        try {

            result.next();
            int job_id = result.getInt(1);
            String title = result.getString(2);
            int min_salary = result.getInt(3);
            int max_salary = result.getInt(4);

            job = new Job(job_id, title, min_salary, max_salary);

        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return job;

    }

    public static List<Job> getAllJobs() {

        List<Job> jobs = new ArrayList<>();
        String query = "select * from hrdb.jobs";
        ResultSet result = connection.execute_query(query);
        try {

            while (result.next()) {
                int job_id = result.getInt(1);
                String title = result.getString(2);
                int min_salary = result.getInt(3);
                int max_salary = result.getInt(4);
                Job job = new Job(job_id, title, min_salary, max_salary);
                jobs.add(job);
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return jobs;

    }

    public static Employee searchByID(int id) {

        String query = "select * from hrdb.employees where employee_id = " + id;
        ResultSet result = connection.execute_query(query);
        try {
            result.next();
            int employee_id = result.getInt(1);
            String first_name = result.getString(2);
            String last_name = result.getString(3);
            String father_name = result.getString(4);
            String mother_name = result.getString(5);
            Date birthdate = result.getDate(6);
            Date hiredate = result.getDate(7);
            int salary = result.getInt(8);
            String blood_type = result.getString(9);
            String gender = result.getString(10);
            int dep_id = result.getInt(11);
            int job_id = result.getInt(12);
            Department department = getDepartmentByID(dep_id);
            Job job = getJobByID(job_id);

            Employee employee = new Employee(employee_id, first_name, last_name, father_name, mother_name, birthdate, hiredate, blood_type, gender, salary, job, department);
            return employee;
        } catch (SQLException ex) {
            //Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

    }

    public static List<Employee> searchByPartOfName(String name) {
        List<Employee> people = new ArrayList<>();
        String query = "select * from hrdb.employees where (first_name like '%" + name + "%' or last_name like '%" + name + "%' or father_name like '%" + name + "%' or mother_name like '%" + name + "%')";
        ResultSet result = connection.execute_query(query);

        try {
            while (result.next()) {
                int employee_id = result.getInt(1);
                String first_name = result.getString(2);
                String last_name = result.getString(3);
                String father_name = result.getString(4);
                String mother_name = result.getString(5);
                Date birthdate = result.getDate(6);
                Date hiredate = result.getDate(7);
                int salary = result.getInt(8);
                String blood_type = result.getString(9);
                String gender = result.getString(10);
                int dep_id = result.getInt(11);
                int job_id = result.getInt(12);
                Department department = getDepartmentByID(dep_id);
                Job job = getJobByID(job_id);

                Employee employee = new Employee(employee_id, first_name, last_name, father_name, mother_name, birthdate, hiredate, blood_type, gender, salary, job, department);
                people.add(employee);
            }

        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return people;
    }

    public static int update_employee(Employee employee) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String birth_date = format.format(employee.getBirth_date());
        String hire_date = format.format(employee.getHire_date());

        String sql = "update  hrdb.employees  set first_name = '" + employee.getFirst_name() + "',last_name='" + employee.getLast_name()
                + "',father_name='" + employee.getFather_name() + "', mother_name = '" + employee.getMother_name() + "',birth_date='" + birth_date + "',hire_date='" + hire_date
                + "', blood_type='" + employee.getBlood_type() + "', salary=" + employee.getSalary() + ", gender='" + employee.getGender()
                + "', departments_dep_id=" + employee.getDepartment().getDep_id() + ", jobs_job_id =" + employee.getJob().getJob_id() + " where employee_id=" + employee.getEmployee_id();
        int error = connection.execute_update(sql);
        return error;
    }

    public static List<Certificate> getCertificatesForEmployee(Employee employee) {
        List<Certificate> certificates = new ArrayList<>();
        String query = "select * from hrdb.certificates where employees_employee_id = " + employee.getEmployee_id();
        ResultSet result = connection.execute_query(query);
        try {
            while (result.next()) {
                int certificate_id = result.getInt(1);
                String type = result.getString(2);
                String source = result.getString(3);
                String specialization = result.getString(4);
                Date date = result.getDate(5);
                Certificate cer = new Certificate(certificate_id, type, source, specialization, date, employee);
                certificates.add(cer);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        return certificates;

    }

    public static void save_certificate(Certificate certificate) {
        Employee employee = certificate.getEmployee();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(certificate.getDate());

        String sql = "insert into hrdb.certificates (type, source, specialization, cert_date, employees_employee_id) values "
                + "('" + certificate.getType() + "','" + certificate.getSource() + "','" + certificate.getSpecialization() + "','"
                + date + "'," + employee.getEmployee_id() + ")";
        System.out.println("++++++++++++++++++ ");
        System.out.println(sql);
        connection.execute_update(sql);

    }

    public static int delete_certificate(Certificate certificate) {

        String sql = "delete from hrdb.certificates where cert_id=" + certificate.getCertificate_id();
        System.out.println(sql);
        int error = connection.execute_update(sql);
        return error;
    }

    public static void update_certificate(Certificate certificate) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(certificate.getDate());
        String sql = "UPDATE hrdb.certificates SET type = '" + certificate.getType() + "', source='" + certificate.getSource()
                + "', specialization='" + certificate.getSpecialization() + "', cert_date='" + date + "' where cert_id=" + certificate.getCertificate_id();

        connection.execute_update(sql);

    }

    public static List<Reward> getRewardsForEmployee(Employee employee) {

        List<Reward> rewards = new ArrayList<>();
        String query = "select * from hrdb.rewards where employees_employee_id = " + employee.getEmployee_id();
        ResultSet result = connection.execute_query(query);
        try {
            while (result.next()) {
                int reward_id = result.getInt(1);
                String type = result.getString(2);
                String source = result.getString(3);
                Date date = result.getDate(4);

                String description = result.getString(5);

                Reward re = new Reward(reward_id, type, date, source, description, employee);
                rewards.add(re);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return rewards;
    }

    /////////////////////
    public static void save_reward(Reward reward) {
        Employee employee = reward.getEmployee();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(reward.getDate());

        String sql = "insert into hrdb.REWARDS (type, source, REWARD_DATE, DESCRIPTION, employees_employee_id) values "
                + "('" + reward.getType() + "','" + reward.getSource() + "','" + date + "','"
                + reward.getDescription() + "'," + employee.getEmployee_id() + ")";

        System.out.println(sql);
        connection.execute_update(sql);
    }

    public static int delete_reward(Reward reward) {

        String sql = "delete from hrdb.rewards where reward_id=" + reward.getReward_id();
        System.out.println(sql);
        int error = connection.execute_update(sql);
        return error;
    }

    public static void update_reward(Reward reward) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(reward.getDate());

        String sql = "update hrdb.REWARDS set type='" + reward.getType() + "', reward_date='" + date + "', source='" + reward.getSource() + "', description='"
                + reward.getDescription() + "' where reward_id=" + reward.getReward_id();

        connection.execute_update(sql);

    }

    public static List<Punishment> getPunishmentsForEmployee(Employee employee) {

        List<Punishment> punishments = new ArrayList<>();
        String query = "select * from hrdb.punishments where employees_employee_id = " + employee.getEmployee_id();
        ResultSet result = connection.execute_query(query);
        try {
            while (result.next()) {
                int punish_id = result.getInt(1);
                String type = result.getString(2);
                String source = result.getString(3);
                Date date = result.getDate(4);

                String description = result.getString(5);

                Punishment p = new Punishment(punish_id, type, date, source, description, employee);
                punishments.add(p);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return punishments;
    }

    /////////////////////
    public static void save_punishment(Punishment pun) {
        Employee employee = pun.getEmployee();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(pun.getDate());

        String sql = "insert into hrdb.punishments (type, source, PUNISHMENT_DATE, DESCRIPTION, employees_employee_id) values "
                + "('" + pun.getType() + "','" + pun.getSource() + "','" + date + "','"
                + pun.getDescription() + "'," + employee.getEmployee_id() + ")";

        System.out.println(sql);
        connection.execute_update(sql);
    }

    public static int delete_punishment(Punishment pun) {

        String sql = "delete from hrdb.punishments where punishment_id=" + pun.getPunishment_id();
        System.out.println(sql);
        int error = connection.execute_update(sql);
        return error;
    }

    public static void update_punishment(Punishment pun) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(pun.getDate());

        String sql = "update hrdb.punishments set type='" + pun.getType() + "', punishment_date='" + date + "', source='" + pun.getSource() + "', description='"
                + pun.getDescription() + "' where punishment_id=" + pun.getPunishment_id();

        connection.execute_update(sql);

    }

    public static void delete_employee(Employee employee) {

        List<Certificate> certs = getCertificatesForEmployee(employee);
        for (Certificate cer : certs) {
            delete_certificate(cer);
        }

        List<Reward> rewards = getRewardsForEmployee(employee);
        for (Reward r : rewards) {
            delete_reward(r);
        }

        List<Punishment> punishments = getPunishmentsForEmployee(employee);
        for (Punishment p : punishments) {
            delete_punishment(p);
        }

        String sql = "delete from hrdb.employees where employee_id=" + employee.getEmployee_id();
        System.out.println(sql);
        connection.execute_update(sql);
    }

    public static List<Object[]> get_departments_with_number_of_employees() {

        String sql = "SELECT d.dep_id, d.dep_name, COUNT(*) as c FROM hrdb.employees AS e inner JOIN hrdb.departments AS d on e.departments_dep_id=d.dep_id  GROUP BY dep_name order by c desc";
        ResultSet result = connection.execute_query(sql);
        List<Object[]> all = new ArrayList<>();
        try {
            while (result.next()) {
                int dep_id = result.getInt(1);
                String name = result.getString(2);
                int count = result.getInt(3);
                Object[] row = new Object[]{dep_id, name, count};
                all.add(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return all;
    }

    public static List<Object[]> get_departments_with_salary_averages() {

        String sql = "SELECT d.dep_id, d.dep_name, avg(e.salary) as v FROM hrdb.employees AS e inner JOIN hrdb.departments AS d on e.departments_dep_id=d.dep_id  GROUP BY dep_name order by v DESC;";
        ResultSet result = connection.execute_query(sql);
        List<Object[]> all = new ArrayList<>();
        try {
            while (result.next()) {
                int dep_id = result.getInt(1);
                String name = result.getString(2);
                float count = result.getFloat(3);
                Object[] row = new Object[]{dep_id, name, count};
                all.add(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return all;
    }

    public static List<Object[]> get_departments_with_number_of_rewards() {

        String sql = "SELECT d.dep_id, dep_name, count(r.reward_id) as c FROM hrdb.rewards as r inner join hrdb.employees as e\n"
                + " on r.employees_employee_id = e.employee_id inner join hrdb.departments as d on\n"
                + " e.departments_dep_id = d.dep_id \n"
                + "group by d.dep_id\n"
                + "order by c desc;";
        ResultSet result = connection.execute_query(sql);
        List<Object[]> all = new ArrayList<>();
        try {
            while (result.next()) {
                int dep_id = result.getInt(1);
                String name = result.getString(2);
                int count = result.getInt(3);
                Object[] row = new Object[]{dep_id, name, count};
                all.add(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return all;
    }

    public static List<Object[]> get_departments_with_number_of_punishments() {

        String sql = "SELECT d.dep_id, dep_name, count(p.punishment_id) as c FROM \n"
                + "hrdb.punishments as p inner join hrdb.employees as e on p.employees_employee_id = e.employee_id\n"
                + "inner join hrdb.departments as d on e.departments_dep_id = d.dep_id \n"
                + "group by d.dep_id\n"
                + "order by c desc;";
        ResultSet result = connection.execute_query(sql);
        List<Object[]> all = new ArrayList<>();
        try {
            while (result.next()) {
                int dep_id = result.getInt(1);
                String name = result.getString(2);
                int count = result.getInt(3);
                Object[] row = new Object[]{dep_id, name, count};
                all.add(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return all;
    }

    public static List<Object[]> get_departments_with_number_of_PhD() {

        String sql = "SELECT d.dep_id, dep_name, count(cer.cert_id) as c FROM \n"
                + "hrdb.certificates as cer inner join hrdb.employees as e on cer.employees_employee_id = e.employee_id\n"
                + "inner join hrdb.departments as d on e.departments_dep_id = d.dep_id \n"
                + "where cer.type = 'PhD'\n"
                + "group by d.dep_id\n"
                + "having c > 0\n"
                + "order by c desc;";
        ResultSet result = connection.execute_query(sql);
        List<Object[]> all = new ArrayList<>();
        try {
            while (result.next()) {
                int dep_id = result.getInt(1);
                String name = result.getString(2);
                int count = result.getInt(3);
                Object[] row = new Object[]{dep_id, name, count};
                all.add(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return all;
    }

    public static List<Object[]> get_Jobs_with_salary_average() {

        String sql = "select j.job_id, j.job_title, avg(e.salary) as v\n"
                + "from hrdb.employees as e inner join hrdb.jobs as j on e.jobs_job_id = j.job_id\n"
                + "group by j.job_id\n"
                + "order by v desc;";
        ResultSet result = connection.execute_query(sql);
        List<Object[]> all = new ArrayList<>();
        try {
            while (result.next()) {
                int job_id = result.getInt(1);
                String name = result.getString(2);
                float avg = result.getFloat(3);
                Object[] row = new Object[]{job_id, name, avg};
                all.add(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return all;
    }

    public static List<Object[]> get_Jobs_with_number_of_employees() {

        String sql = "select j.job_id, j.job_title, count(*) as v\n"
                + "from hrdb.employees as e inner join hrdb.jobs as j on e.jobs_job_id = j.job_id\n"
                + "group by j.job_id\n"
                + "order by v desc;";
        ResultSet result = connection.execute_query(sql);
        List<Object[]> all = new ArrayList<>();
        try {
            while (result.next()) {
                int job_id = result.getInt(1);
                String name = result.getString(2);
                int count = result.getInt(3);
                Object[] row = new Object[]{job_id, name, count};
                all.add(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return all;
    }

    public static List<Object[]> get_employees_sorted_by_salary() {

        String sql = "SELECT employee_id, concat(first_name, ' ', father_name, ' ', last_name) as full_name, salary "
                + "   FROM hrdb.employees order by salary desc;";
        ResultSet result = connection.execute_query(sql);
        List<Object[]> all = new ArrayList<>();
        try {
            while (result.next()) {
                int emp_id = result.getInt(1);
                String name = result.getString(2);
                int salary = result.getInt(3);
                Object[] row = new Object[]{emp_id, name, salary};
                all.add(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return all;
    }

    public static List<Object[]> get_employees_sorted_by_punishments() {

        String sql = "select employee_id, concat(first_name, ' ', father_name, ' ', last_name) as full_name, count(punishment_id) as count"
                + " from employees_punishments_view group by employee_id order by count desc;";
        ResultSet result = connection.execute_query(sql);
        List<Object[]> all = new ArrayList<>();
        try {
            while (result.next()) {
                int emp_id = result.getInt(1);
                String name = result.getString(2);
                int count = result.getInt(3);
                Object[] row = new Object[]{emp_id, name, count};
                all.add(row);

            }
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return all;
    }

    public static void disconnect() {
        connection.disconnect();

    }

}
